# TP5 : Partage du bus dans les architectures multi-processeurs

## B. Architecture matérielle

chaque proc a son propore tty,
TTY = NPROCs*16octets, chaque TTY 4 registres adressables

quel est la différence entre FBF et TTY ? 
-> hyp 1 : FBF image , TTY caractère 

#### Question B1 : En consultant l'en tête du fichier pibus_frame_buffer.h, précisez la signification des arguments du constructeur du composant PibusFrameBuffer


- sc_module_name		name    : nom de l'instance
- unsigned int  		index   : target index      
- pibusSegmentTable		segmap  : segment table
- unsigned int		latency	: nombre cycles d'attentes
- unsigned int		width	: nombre de pixels par ligne 
- unsigned int		height  : nombre de lignes 
- unsigned int		subsampling : default = 420

#### Question B2 : Quelle est la longueur du segment associé à ce composant 

largeur * longueur = 256 * 256 octets = 64 Koctets

16 lignes de 8 mots 
512 o pour chacun , instructions et donnée 


## C. Compilation de l'application logicielle

256*2656 , échiquier de 64 cases. 32*32 pixels 

fb_sync_write()

#### Question C1 :  Pourquoi faut-il utiliser un appel système pour accéder (en lecture comme en écriture) au contrôleur de frame-buffer ?  Que se passe-t-il si un programme utilisateur essaie de lire ou d'écrire directement dans le Frame Buffer, sans passer par un appel système ? 
 
i) Pour gérer une ressource matériel il est nécessaire d'être en mode kernel 
ii) Le programme utilisateur n'a pas les droits d'accès pour le segment kernel. Si le programme essaie d'y accéder, cela créer une exception(SegFault) 

#### Question C2 : Pourquoi préfère-t-on construire une ligne complête dans un tableau intermédiaire de 256 pixels plutôt que d'écrire directement l'image - pixel par pixel - dans le frame buffer? 

Pour - occuqué le bus 
éviter des pertes de données 

#### Question C3 : Consultez le fichier stdio.c, et expliquez la signification des trois arguments de l'appel système fb_sync_write(). Complétez le fichier main.c en conséquence. 

commande à faire : cd $GIET_APP_PATH
 
- offset : offset dans le buffer
- buffer : adresse de base du buffer 
- length : nombre d'octets à transferer 

ssh -X (Machine virtuelle) : permet de specifier au systeme qu'il peut acceder au terminal de la machine de developpement tout en etant sur une VM. 

## D. Caractérisation de l'application logicielle 

#### Question D1 : Quel est le nombre de cycles nécessaires pour afficher l'image avec un seul processeur. Combien d'instructions ont été exécutées pour afficher l'image? Quel est le nombre moyen de cycles par instruction (CPI) ?

Nombre de cycles :  cycles
Nombre instructions : 4003722
CPI : 1.37372

*** proc[0] at cycle 5500000
- INSTRUCTIONS       = 4003722
- CPI                = 1.37372
- CACHED READ RATE   = 0.241966
- UNCACHED READ RATE = 0.00132751
- WRITE RATE         = 0.126301
- IMISS RATE         = 0.00924989
- DMISS RATE         = 0.0106868
- IMISS COST         = 15.917
- DMISS COST         = 14.7441
- UNC COST           = 6
- WRITE COST         = 0
bcu : Statistics
master 0 : n_req = 558376 , n_wait_cycles = 558376 , access time = 1
master 1 : n_req = 0 , n_wait_cycles = 0 , access time = -nan
master 2 : n_req = 0 , n_wait_cycles = 0 , access time = -nan



#### Question D2 : Quel est le pourcentage d'écritures sur l'ensemble des instructions exécutées ? Quel est le pourcentage de lectures de données ? Quels sont les taux de miss sur le cache instruction et sur le cache de données ? Quel est le coüt d'un miss sur le cache instructions ? Quel est le coût d'un miss sur le cache de données ? Quel est le coût d'une écriture pour le processeur ? On rappelle que les couts se mesurent en nombre moyen de cycles de gel du processeur. Comment expliquez-vous que ces coûts ont des valeurs non entières? 

i) WRITE RATE = 0.126301
ii)
- CACHED READ RATE   = 0.241966
- UNCACHED READ RATE = 0.00132751

iii) 
- WRITE RATE         = 0.126301
- IMISS RATE         = 0.00924989

iv)
- IMISS COST         = 15.917

v) 120% de ibrahima ; source : tkt 
- DMISS COST         = 14.7441

vi)
- WRITE COST         = 0

Le cout du miss dépend de l'attente de l'autorisation du bus. -> le cout du miss est un réel.


*** proc[0] at cycle 5500000
- INSTRUCTIONS       = 4003722
- CPI                = 1.37372
- CACHED READ RATE   = 0.241966
- UNCACHED READ RATE = 0.00132751
- WRITE RATE         = 0.126301
- IMISS RATE         = 0.00924989
- DMISS RATE         = 0.0106868
- IMISS COST         = 15.917
- DMISS COST         = 14.7441
- UNC COST           = 6
- WRITE COST         = 0
bcu : Statistics
master 0 : n_req = 558376 , n_wait_cycles = 558376 , access time = 1
master 1 : n_req = 0 , n_wait_cycles = 0 , access time = -nan
master 2 : n_req = 0 , n_wait_cycles = 0 , access time = -nan

####  Question D3 : Evaluez le nombre de transactions de chaque type pour cette application. Que remarquez-vous ? 

nb transactions : 
write : instructions * write_rate = 4003722 * 0.126301
read_instructions  = instructions * (CACHED READ RATE + UNCACHED READ RATE) = 4003722 * (0.241966 + 0.00132751)

## E. Exécution sur architecture multi-processeurs

k % NPROCS == i

Le numéro est une valeur cablée au moment de la fabrication dans le registre protégé 
-> procid()

