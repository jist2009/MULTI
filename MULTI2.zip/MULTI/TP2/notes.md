# TP2 : Déploiement de code sur processeur programmable 

# A. Objectifs 
arbitre bus, proc, ROM, RAM, TTY
ligne de cache : 4 mots
- miss instruction : proc gelé durant MISS, controleur de cache exe transaction en rafale = lire une ligne de cache
- miss data : proc gelé, controleur transaction rafale = lire ligne de cache
- read uncached : lect donnée non cachable 
### pourquoi une donnée ne doit pas être cachable ? 
--> inutile 
--> pour le tty, il génère des données différents mais sur la meme adresse, si existance cache, donnée dans cache jamais changé car le cache voit que la nouvel donnée a la meme adresse que celle dans le cache, donc pourquoi changez. ### Donc le cache ne vérifie pas qu'ils n'ont pas la meme valeur --> je pense qu'on a pas inventé ce système car coute cher et le problème n'existe pas 

- write : proc non tjs gelé, tampon écriture . écriture un mot sur le pibus.


# C Modélisation de l'architecture matérielle

### Question C1 : Quelles valeurs doivent prendre les paramètres icache_words, icache_sets, icache_ways, dcache_words, dcache_sets, dcache_ways , wbuf_depth pour donner aux caches les caractéristiques demandées ci-dessus? 

### Question C2 : Pourquoi le segment seg_reset n'est il pas assigné au même composant matériel que les 6 autres segments mémoire seg_kcode, seg_kdata, seg_kunc, seg_stack, seg_code, seg_data

###  Question C3 Expliquer pourquoi le segment seg_tty doit être non cachable.

--> pour le tty, il génère des données différents mais sur la meme adresse, si existance cache, donnée dans cache jamais changé car le cache voit que la nouvel donnée a la meme adresse que celle dans le cache, donc pourquoi changez. ### Donc le cache ne vérifie pas qu'ils n'ont pas la meme valeur --> je pense qu'on a pas inventé ce système car coute cher et le problème n'existe pas 

###  Question C4 Parmi les 8 segments utilisés dans cette architecture, quels sont les segments protégés (c'est à dire accessibles seulement quand le processeur est en mode superviseur). Comment est réalisée cette protection ? 
adresse > 0x7FFF FFFF = protégé, sinon utilisateur
segments protégés : seg_kcode, seg_kunc, seg_kdata, seg_tty, seg_reset
dans le processus, on peut changer de mode (je ne retrouve plus la fonction est la variable)
(cours dans L3S6)

---------------------------------------------
Il faut chargé en mémoire le code binaire exécutable par le loader(un programme) pris dans le disk. 

-----------------------------------
il faut créer le loader 

### executé le code 



# D. Système d'exploitation: GIET

GIET = Gestionnaire d'Interruptions, Exceptions et Trappes (= appels systèmes)
--> non réaliste car manque mémoire virtuelle

# je n'ai pas les fichiers, doit prendre depuis l'univ 

## Je vais push et je vais le faire a la maison 
---> faisable sans exe







# E. Génération du code binaire 

cross-compilateur GCC
sys.bin et app.bin compilé séparément 
main.c 

## sys.bin
reset.s code boot, 0xBFC et signal reset, init les périphériques et charger code système en mémoire.
Notre cas : code système déjà chargé en mémoire au démarrage machine

### Question E1 : Donnez trois raisons qui justifient que le code boot s'exécute nécessairement en mode superviseur

- si code boot en mode utilisateur -> l'utilisateur peut modifier le code = risque de destruction de l'ordinateur --> protection face à l'extérieur 
- Le processeur doit configurer des registres internes qui ne sontt pas accessibles en mode utilisateur
- accès direct aux périphériques -> nécessite en mode kernel 
- init vecteur d'interruption

###  Question E2 Quelle est la convention (non standard) permettant au code de boot du GIET de récupérer l'adresse de la première instruction de la fonction main() ? 

convention GIET : L'adresse de la fonction main() est stockée à une adresse mémoire prédéfinie.

non conventionnel car : l'OS doit lire l'en tête du fichier exécutable (donc l'adresse du main change en fonction du fichier exécutable). 

brumel et reicha ne fonctionnent pas, il faut se connecter sur brahms
-> la compilation manuelle (= phase d'éditions de liens) a permis de créer les fichiers objets

sys.ld => indique quels segments mémoire pour chaque objet. 
les adresses des segments sont dans le fichier seg.ld + adr seg périph, 

adr base de logiciel dans seg.ld, adr base matériel dans tp2_top.cpp

###  Question E3 Que se passe-t-il si les adresses définies dans ces deux fichiers ne sont pas égales entre elles ? Que se passe-t-il si l'adresse construite par le processeur ne correspond à aucun segment défini dans l'architecture ? 

i) donc a un moment, le processeur va lire dans les deux fichiers 
--> si adresse du tp2_top.cpp sont fausses
--> si l'adresse est avancé que l'adresse réelle => ca va enlever certains codes 
----> sauter des codes erreur manque des trucs 
--> si l'adresse est reculé que l'adresse réelle => commancement dans des segments non alloués
----> abandon 

réponse : l'édition de liens ne fonctionnera pas. si on ne fait pas l'édition de liens, le boot initialise/démarre sur une mauvaise adresse -> signal un erreur 

revoir les éditions de lien sur son fonctionnement

### Question E4 : En analysant le contenu du fichier sys.ld, déterminez quels sont les objets logiciels placés dans chacun des 2 segments qui contiennent du code système exécutable : seg_reset, seg_kcode. 

signification du code exécutable ou non exécutable : 

c'est quoi un objet logiciel : un fichier objet ? 
dans le segment "seg_reset_base" : il y a que l'objet reset.o 
dans le segment "seg_kcode_base" : giet.o 

### Question E5 : En analysant le contenu du fichier sys.bin.txt, déterminez la taille effective du code dans les deux segments seg_reset et seg_kcode. 

seg_reset : bfc00024 + 4 - bfc00000 = 0x28
seg_kcode : 8000227c + 4 - 80000000 = 0x2280

# F. Execution 