# TP4  Caractérisation et dimensionnement des caches

# A Objectifs

évaluer l'influence des différentes caractéristiques des caches.
paramètre 1 : taille des caches
paramètre 2 : nb mot pas ligne
paramètre 3 : niveaux d'associativité 
paramètre 4 : pronfondeur du tampon d'écriture postées

cache très grand -> taux de miss 0
système mémoire <presque parfait>

taille caches limités par : 
    - surface de silicium qui coute cher
    - temps d'accès qui augmente -> modifie la fréquence du processeur

cache associatif < cache direct pour le taux de miss
Mais le cache associatif occupe (un peu) plus de surface et est (un peu) plus lent

on utilise l'appel système proctime() du GIET, qui renvoie le contenu d'un compteur de cycles interne au processeur. 

# B Architecture matérielle

facon récursive, somme des N premiers nombres entiers , N dans [0, 29], affiche le résultat du calcul à chaque itération de la boucle principale 

# C Système mémoire presque parfait

Compilation prototype virtuel : soclib-cc -p tp1.desc -t systemcass -o simul.x



