
#include "stdio.h"

__attribute__((constructor)) void main() {
    char c;
    char s[] = "\n Hello World! \n";

    while(1) {
        if(char *s = tty_puts(s) != 0){
            printf("Erreur\n");
        }
        tty_getc(c);
    }

} // end main

// doit afficher Hello World sur le TTY 
// puis se bloque attente saisi clavier
// avant itération 
// deux syscall : 
